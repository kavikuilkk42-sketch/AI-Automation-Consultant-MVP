# Deployment checklist

1. GitHub repository created.
2. Confirm `.env` is NOT committed.
3. Push code.
4. Render -> New -> Web Service.
5. Connect repository.
6. Build command: `npm install`
7. Start command: `npm start`
8. Add environment variables:
   - AI_PROVIDER=demo (first deploy)
   - GEMINI_MODEL=gemini-2.5-flash
   - GEMINI_API_KEY=<secret> (only when you have a valid key)
9. Deploy.
10. Open the generated `onrender.com` URL.
11. Test chat + lead form.
12. For a real client, replace JSON lead storage with a managed database before handling real customer/patient data.