import express from "express";
import dotenv from "dotenv";
import fs from "fs/promises";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT || 5000);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const businessPath = path.resolve(__dirname, process.env.BUSINESS_FILE || "./data/business.json");
const leadsPath = path.join(__dirname, "data", "leads.json");

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

async function readBusiness() {
  return JSON.parse(await fs.readFile(businessPath, "utf8"));
}

async function readLeads() {
  try {
    return JSON.parse(await fs.readFile(leadsPath, "utf8"));
  } catch {
    return [];
  }
}

async function writeLeads(leads) {
  await fs.writeFile(leadsPath, JSON.stringify(leads, null, 2), "utf8");
}

function demoReply(message, business) {
  const m = message.toLowerCase();

  if (/(hello|hi|hey|vanakkam)/.test(m)) {
    return `Hello! 👋 Welcome to ${business.name}. How can I help you today?`;
  }

  if (/(time|timing|open|opening|close|hours)/.test(m)) {
    return `${business.name} is open ${business.hours}.`;
  }

  if (/(doctor|specialist|dermat|skin|dentist)/.test(m)) {
    const skin = /skin|dermat/.test(m);
    const dentist = /dentist|dental|tooth|teeth/.test(m);
    if (skin) return "Our dermatologist is Dr. Priya. Would you like to make an appointment enquiry?";
    if (dentist) return "Our dentist is Dr. Arun. Would you like to make an appointment enquiry?";
    return "Our doctors are " + business.doctors.map(d => `${d.name} (${d.specialty})`).join(", ") + ".";
  }

  if (/(service|services|treatment)/.test(m)) {
    return `We provide ${business.services.join(", ")}. Which service are you interested in?`;
  }

  if (/(appointment|book|booking|schedule)/.test(m)) {
    return "Sure. I can help with an appointment enquiry. Please provide your name and phone number.";
  }

  if (/(price|fee|cost|charge)/.test(m)) {
    return "Our consultation fee has not been configured in this demo. A clinic staff member can confirm the exact fee.";
  }

  if (/(location|address|where)/.test(m)) {
    return "Please contact the clinic directly for the current location details.";
  }

  return `I can help with doctors, services, opening hours and appointment enquiries at ${business.name}. What would you like to know?`;
}

async function geminiReply(message, business, history = []) {
  const key = (process.env.GEMINI_API_KEY || "").trim();
  if (!key) return null;

  const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";
  const prompt = `
You are the AI receptionist for ${business.name}.
Business information:
${JSON.stringify(business, null, 2)}

Rules:
- Answer only from the supplied business information.
- Never invent prices, availability, doctors, services or policies.
- You are a receptionist, not a doctor.
- Do not diagnose or give medical treatment instructions.
- If the customer wants an appointment, collect name and phone number and say availability will be confirmed by staff because no live calendar is connected.
- Be concise, friendly and professional.
- If information is unavailable, say a staff member can assist.

Conversation:
${history.map(x => `${x.role}: ${x.text}`).join("\n")}

Customer:
${message}
`;

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "x-goog-api-key": key,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }]
    })
  });

  if (!response.ok) {
    const body = await response.text();
    console.error("Gemini API:", response.status, body);
    return null;
  }

  const data = await response.json();
  return data?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim() || null;
}

app.get("/api/health", async (_req, res) => {
  res.json({
    ok: true,
    aiProvider: process.env.AI_PROVIDER || "demo",
    aiConfigured: Boolean((process.env.GEMINI_API_KEY || "").trim())
  });
});

app.get("/api/business", async (_req, res) => {
  res.json(await readBusiness());
});

app.post("/api/chat", async (req, res) => {
  const message = String(req.body.message || "").trim();
  const history = Array.isArray(req.body.history) ? req.body.history.slice(-12) : [];

  if (!message) return res.status(400).json({ ok: false, error: "Message is required." });

  const business = await readBusiness();
  let reply = null;

  if ((process.env.AI_PROVIDER || "demo").toLowerCase() === "gemini") {
    try {
      reply = await geminiReply(message, business, history);
    } catch (error) {
      console.error("Gemini connection error:", error.message);
    }
  }

  if (!reply) reply = demoReply(message, business);

  res.json({
    ok: true,
    reply,
    mode: reply && process.env.AI_PROVIDER === "gemini" && process.env.GEMINI_API_KEY ? "ai-or-fallback" : "demo"
  });
});

app.post("/api/leads", async (req, res) => {
  const name = String(req.body.name || "").trim();
  const phone = String(req.body.phone || "").trim();
  const requirement = String(req.body.requirement || "").trim();

  if (!name || !phone) {
    return res.status(400).json({ ok: false, error: "Name and phone are required." });
  }

  const leads = await readLeads();
  const lead = {
    id: crypto.randomUUID(),
    name,
    phone,
    requirement,
    createdAt: new Date().toISOString(),
    status: "new"
  };

  leads.push(lead);
  await writeLeads(leads);

  res.json({ ok: true, lead: { ...lead, phone: phone.slice(0, 3) + "****" + phone.slice(-2) } });
});

app.get("/api/leads", async (req, res) => {
  const adminKey = String(req.headers["x-admin-key"] || "");
  if (!process.env.ADMIN_KEY || adminKey !== process.env.ADMIN_KEY) {
    return res.status(401).json({ ok: false, error: "Unauthorized." });
  }
  res.json({ ok: true, leads: await readLeads() });
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`AI Business Assistant running on port ${PORT}`);
  console.log(`Local: http://localhost:${PORT}`);
});