# AI Automation Consultant MVP

A fast, reusable AI Business Assistant / AI Receptionist MVP for selling automation services.

## What is included
- Responsive chatbot web UI
- Business knowledge from `data/business.json`
- FAQ / doctor / services / appointment enquiry flow
- Lead capture
- Demo mode that works without an AI API key
- Optional Gemini AI mode
- Health endpoint
- Render deployment configuration

## Local run
```bash
npm install
npm start
```
Open http://localhost:5000

## Enable Gemini
Create `.env` from `.env.example` and set:
```env
AI_PROVIDER=gemini
GEMINI_API_KEY=YOUR_KEY
GEMINI_MODEL=gemini-2.5-flash
```
If Gemini fails or no key is configured, the app safely falls back to demo mode.

## Customize for a client
Edit `data/business.json`:
- name
- tagline
- hours
- phone
- services
- doctors
- faq

## Important production note
The included lead storage is intentionally lightweight for the sales demo. Render's default filesystem is ephemeral, so replace `data/leads.json` with a managed database (for example Postgres/Supabase) before using real client/patient data in production.

## Deploy on Render
1. Push this folder to GitHub.
2. Render -> New -> Web Service.
3. Select the GitHub repository.
4. Build: `npm install`
5. Start: `npm start`
6. Add `GEMINI_API_KEY` as a secret if using AI mode.
7. Deploy.

Do not commit `.env` or API keys.